<?php




        if(!isset($_POST['name'])  || empty($_POST['name'])) 
        {
            die("You need to enter your name.");
        }

        if(!isset($_POST['lastName'])  || empty($_POST['lastName'])) 
        {
            die("You need to enter your last name.");
        }

        if(!isset($_POST['email'])  || empty($_POST['email'])) 
        {
            die("You need to enter email.");
        }

        if(!isset($_POST['password'])  || empty($_POST['password'])) 
        {
            die("You need to enter password.");
        }

        if(!isset($_POST['date'])  || empty($_POST['date'])) 
        {
            die("You need to enter date.");
        }


        require_once "baza.php";


        $name = $_POST['name'];
        $lastName = $_POST['lastName'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $date = $_POST['date'];

        $checkEmail = $baza->query("SELECT * FROM users WHERE email = '$email'");

        if($checkEmail->num_rows >= 1)
        {
            die("There is already a user with this email adress.");
        }

        $name = $baza->real_escape_string($name);
        $lastName = $baza->real_escape_string($lastName);
        $email = $baza->real_escape_string($email);
        $password = $baza->real_escape_string($password);
        $date = $baza->real_escape_string($date);


        $baza->query("INSERT INTO users (name, last_name, email, password, birthday_day) VALUES ('$name', '$lastName', '$email', '$password', '$date')");


        header("Location: ");














?>