        <?php

            if(!isset($_POST['email']) || empty($_POST['email']))
            {
                die("You need to enter your email adress.");
            }

            if(!isset($_POST['password']) || empty($_POST['password']))
            {
                die("You need to enter your email adress.");
            }


            require_once "baza.php";


            
            $email = $_POST['email'];
            $password = $_POST['password'];

            $email = $baza->real_escape_string($email);
            $password = $baza->real_escape_string($password);


            $checkEmail = $baza->query("SELECT * FROM users WHERE email = '$email'");

            if($checkEmail->num_rows == 1 )
            {
                $user = $checkEmail->fetch_assoc();
                $checkPassword = password_verify($password, $user['password']);

                if($checkPassword == true)
                {

                    if(session_status() == PHP_SESSION_NONE)
                    {
                        session_start();
                    }

                    $_SESSION['logedInUser'] = true;
                    $_SESSION['userId'] = $user['id'];
                    header("Location: ../index.php");
                }
                
                else
                {
                    die("Incorect email or password.");
                }

            }
 
            else
            {
                die("Incorect email or password.");
            }




        ?>