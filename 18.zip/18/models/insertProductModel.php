        <?php


        if(!isset($_POST['name']) || empty($_POST['name'])){
            die("A");
        }

        if(!isset($_POST['description']) || empty($_POST['description'])){
            die("B.");
        }

        if(!isset($_POST['price']) || empty($_POST['price'])){
            die("C.");
        }

        if(!isset($_POST['procurementDate']) || empty($_POST['procurementDate'])){
            die("D.");
        }

        if(!isset($_POST['amount']) ){
            die("E.");
        }

        require_once "baza.php";

        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $procurementDate = $_POST['procurementDate'];
        $amount = $_POST['amount'];

        $name = $baza->real_escape_string($name);
        $description = $baza->real_escape_string($description);
        $price = $baza->real_escape_string($price);
        $procurementDate = $baza->real_escape_string($procurementDate);
        $amount = $baza->real_escape_string($amount);



        $insertProduct = $baza->query("INSERT INTO products (`name`, `description`, `price`, `procurement_date`, `amount`) VALUES ('$name', '$description', '$price', '$procurementDate', '$amount')");

        header("Location: index.php");
        
        ?>