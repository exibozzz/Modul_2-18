<?php

    require_once ("models/baza.php");

    $checkOrders = $baza->query("SELECT * FROM orders");

    $checkOrdersAssoc = $checkOrders->fetch_all(MYSQLI_ASSOC);



    if(session_status() == PHP_SESSION_NONE)
    {
        session_start();
    }



?>


<!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Orders</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>

    <body>

                <div class="container bg-dark d-flex col-12 justify-content-center p-1">

                        <a href="index.php" class="nav-link m-2">Home</a>
                        <a href="myCart.php" class="nav-link m-2">Cart</a>
                        <?php if(isset($_SESSION['logedInUser'])): ?>
                            <a href="logout.php" class="nav-link m-2">Logout</a>
                        <?php else: ?>    
                            <a href="login.php" class="nav-link m-2">Login</a>
                        <?php endif ?>
                        <a href="search.php" class="nav-link m-2">Search</a>
                        <a href="insert.php" class="nav-link m-2">Insert</a>  

                </div>



            <div class="container">             

                <h1 class="text-center">Your Orders</h1> 

                <table class="table mt-5"  >
                        <thead>
                            <tr class="bg-info">
                                <th scope="col">Name </th>
                                <th scope="col">User ID</th>
                                <th scope="col">Product ID</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Price</th>
                            </tr>
                        </thead>

                        <?php foreach($checkOrdersAssoc as $order): ?>
                            <tr>
                                <td><?= $order['product_name']?></td>
                                <td><?= $order['user_id']?></td>
                                <td><?= $order['product_id']?></td>
                                <td><?= $order['amount']?></td>
                                <td><?= $order['price']?></td>
                            </tr>
                        <?php endforeach; ?>

                    </table>

            </div>


        
    



        
    </body>
</html>