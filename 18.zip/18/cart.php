<?php


if (!isset($_POST['orderAmount']) || empty($_POST['orderAmount']))
{
    die("You must enter amount to order.");
}

if(!isset($_POST['productId']) || empty($_POST['productId']))
{
    die("Product missing");
}

require_once "models/baza.php";

if(session_status() == PHP_SESSION_NONE)
{
    session_start();
}
$productName = $_POST['productName'];
$orderAmount = $_POST['orderAmount'];
$productId = $_POST['productId'];
$userId = $_SESSION['userId']; 


$checkPrice = $baza->query("SELECT price FROM products WHERE id = $productId");

$checkPriceAssoc = $checkPrice->fetch_assoc();

$price = $checkPriceAssoc['price'];

$price = $price * $orderAmount;

$productName = $baza->real_escape_string($productName);
$orderAmount = $baza->real_escape_string($orderAmount);
$productId = $baza->real_escape_string($productId);
$userId = $baza->real_escape_string($userId);
$price = $baza->real_escape_string($price);

var_dump($productName);


$insertOrder = $baza->query("INSERT INTO orders (product_name, user_id, product_id, amount, price) VALUES ('$productName', $userId, $productId, $orderAmount, $price) ");

header("Location: index.php");
?>