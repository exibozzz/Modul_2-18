            <?php

            ?>



            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Registration</title>
                <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
                <script src="js/bootstrap.min.js"></script>
                <link rel="stylesheet" type="text/css" href="css/style.css">
            </head>
            <body>


                    <div class="container bg-dark d-flex col-12 justify-content-center p-1">

                        <a href="index.php" class="nav-link m-2">Home</a>
                        <a href="myCart.php" class="nav-link m-2">Cart</a>

                        <?php if(isset($_SESSION['logedInUser'])): ?>
                            <a href="logout.php" class="nav-link m-2">Logout</a>
                        <?php else: ?>    
                            <a href="login.php" class="nav-link m-2">Login</a>
                        <?php endif ?>
                        <a href="search.php" class="nav-link m-2">Search</a>
                        <a href="insert.php" class="nav-link m-2">Insert</a>  

                    </div>

        

                    <form class="d-flex justify-content-center align-items-center flex-column col-12 bg-info" method="POST" action="models/registrationModel.php" >
                        <p class="display-4">Create Account</p>
                
                        <div class="form-group col-3">
                            <label for="name" class="col-12 mt-2">Name</label>
                            <input type="text" name="name" class="form-control col-12" id="name" placeholder="Enter your name" required>
                        </div>
                        <div class="form-group col-3">
                            <label for="lastName" class="col-12">Last Name</label>
                            <input type="text" name="lastName" class="form-control col-12" id="lastName" placeholder="Enter your last name" required>
                        </div>
                        <div class="form-group col-3">
                            <label for="exampleInputEmail1" class="col-12">Email address</label>
                            <input type="email" name="email" class="form-control col-12" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        <div class="form-group col-3">
                            <label for="exampleInputPassword1" class="col-12">Password</label>
                            <input type="password" name="password" class="form-control col-12" id="exampleInputPassword1" placeholder="Password" required>
                        </div>
                        <div class="form-group col-3">
                            <label class="form-check-label col-12" for="exampleCheck1">Date</label>
                            <input type="date" name="date"  class="form-control col-12" id="exampleCheck1" placeholder="Enter your birthay date" required>

                        </div>
                        <button type="submit" class="btn btn-primary col-2 mb-3">Register</button>
                        <a href="login.php" class="display-5 text-white">Already have account?</a>

                    </form> 



        
            
        </body>
</html>