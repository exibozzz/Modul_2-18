    <?php

         require_once "models/baza.php";

         $products = $baza->query("SELECT * FROM products");

         $assocProducts = $products->fetch_all(MYSQLI_ASSOC);

         if(session_status() == PHP_SESSION_NONE)
         {
            session_start();
         }

    ?>


    <!DOCTYPE html>
    <html lang="en">
    <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>All Products</title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>

            
                <div class="container bg-dark d-flex col-12 justify-content-center p-1">
                        <a href="index.php" class="nav-link m-2">Home</a>
                        <a href="myCart.php" class="nav-link m-2">Cart</a>

                        <?php if(isset($_SESSION['logedInUser'])): ?>
                            <a href="logout.php" class="nav-link m-2">Logout</a>
                        <?php else: ?>    
                            <a href="login.php" class="nav-link m-2">Login</a>
                        <?php endif ?>
                        <a href="search.php" class="nav-link m-2">Search</a>
                        <a href="insert.php" class="nav-link m-2">Insert</a>                            
                </div>

          

        <div class="container d-flex flex-wrap justify-content-center mt-5 mb-3">

                <?php foreach($assocProducts as $product):?>

                           
                                <div class="col-4 d-inline-block justify-content-center align-items-center card col-5 m-2 ">
                                        <img src="https://img.gigatron.rs/img/products/large/image64a288c1cdf5f.jpg" class="card-img-top mb-1 " alt="Product Image">
                                        <h3 class="mb-4"><strong><?= $product['name']?></strong></h3>
                                        <p><?= $product['description']?></p>
                                        <hr>
                                        <p><strong>Price:</strong> <?= $product['price']?>&euro;</p>
                                        <hr>
                                        <p><strong>Procurement date:</strong> <?= $product['procurement_date']?></p>
                                        <hr>                                       
                                        <?php if($product['amount'] < 1):?>
                                            <span class="badge bg-danger col-3 p-2">Status: N/A</span>
                                        <?php else: ?>
                                            <span class="badge bg-success col-3 p-2">Status: <?= $product['amount']?></span>
                                        <?php endif; ?>                                       
                                        <br></br>
                                        <a href="product.php?id=<?= $product['id'] ?>" class="d-flex justify-content-center align-items-center btn btn-success mb-2 col-12">See Product</a>  
                                        
                                        <?php if(isset($_SESSION['logedInUser'])):?>

                                            <h1>Order</h1>

                                        <form method="POST" action="cart.php">   
                                            <input type="number" name="orderAmount" placeholder="Enter the quantity:" required>
                                            <input type="hidden" name="productId" value="<?= $productAssocInfo['id']?>">
                                            <input type="hidden" name="productName" value="<?= $productAssocInfo['name']?>">  

                                            <div class="d-flex justify-content-center align-items-center ">                                       
                                                <button href="myCart.php" class="btn btn-danger mb-2 ">Add to cart</button>  
                                                <img src="images/cart.png" alt="Cart icon" >
                                            </div>

                                        </form>

                                        <?php else: ?>
                                        <a href="registration.php" class="btn btn-info mb-2 ">Register to add to cart</a>  
                                        <?php endif;?>
                                </div>
                           
                <?php endforeach; ?>


                <div class="h-300 col-3 border-5 border-bottom border-black">

                    <div class="d-flex align-items-center justify-content-center w-100" style="background-color: #FFA07A; height: 70%; ">1</div>
                    <div class="d-flex align-items-center justify-content-center w-100 bg-secondary" style="background-color: #653208; height: 30%;">2</div>                         
      
                </div>
        </div>
        


           

                



      
            


</body>
</html>