<?php
 
        if(!isset($_GET['id']) || empty($_GET['id']))
        {
            die("Id product missing.");
        }


        require_once "models/baza.php";

        $idProduct = $_GET['id'];

        $checkId = $baza->query("SELECT * FROM products WHERE id = $idProduct");

        $productAssocInfo = $checkId->fetch_assoc();

        if(session_status() == PHP_SESSION_NONE)
        {
            session_start();
        }


        

?>


<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?=$productAssocInfo['name']?></title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/style.css">
            
        </head>


        <body>

        <div class="container bg-dark d-flex col-12 justify-content-center p-1">

                <a href="index.php" class="nav-link m-2">Home</a>
                <a href="cart.php" class="nav-link m-2">Cart</a>

                <?php if(isset($_SESSION['logedInUser'])): ?>
                    <a href="logout.php" class="nav-link m-2">Logout</a>
                <?php else: ?>    
                    <a href="login.php" class="nav-link m-2">Login</a>
                <?php endif ?>
                <a href="search.php" class="nav-link m-2">Search</a>
                <a href="insert.php" class="nav-link m-2">Insert</a>  

        </div>

        <div class="container d-flex justify-content-center align-items-center mt-5">

                <div class="col-5 card">
                            <img src="https://img.gigatron.rs/img/products/large/image64a288c1cdf5f.jpg" class="card-img-top mb-1 img " alt="Product Image">
                            <h3 class="mb-4"><strong><?= $productAssocInfo['name']?></strong></h3>
                            <p><?= $productAssocInfo['description']?></p>
                            <hr>
                            <p><strong>Price:</strong> <?= $productAssocInfo['price']?>&euro;</p>
                            <hr>
                            <p><strong>Procurement date:</strong> <?= $productAssocInfo['procurement_date']?></p>
                            <hr>    

                            <?php if($productAssocInfo['amount'] < 1):?>
                                <span class="badge bg-danger p-2 text-end">Status: N/A</span>
                            <?php else: ?>
                                <span class="d-flex justify-content-center align-items-center badge bg-success p-1 col-2">Status: <?= $productAssocInfo['amount']?></span>
                            <?php endif; ?>                                       
                            <br></br>
                            <a href="product.php?id=<?= $productAssocInfo['id'] ?>" class="d-flex justify-content-center align-items-center btn btn-success mb-2 text-center">See Product</a>  


                            <?php if(isset($_SESSION['logedInUser'])):?>

                                <form method="POST" action="cart.php">
                                    <input type="number" name="orderAmount" placeholder="Enter amount" required>
                                    <input type="hidden" name="productId" value="<?= $productAssocInfo['id']?>">
                                    <input type="hidden" name="productName" value="<?= $productAssocInfo['name']?>">

                                    <button href="myCart.php" class="btn btn-info mb-2 ">Add to cart</button>  
                            </form>

                            <?php else: ?>
                                <a href="registration.php" class="btn btn-info mb-2 ">Register to add to cart</a>  
                            <?php endif;?>
                    </div>

        </div>

 


        </body>
        </html>